import React, { useState } from 'react'
import { Toast } from '../components/Toast.jsx'

export default function TagEditor(){
  const [filePath, setFilePath] = useState('')
  const [tags, setTags] = useState({ title:'', artist:'', album:'', genre:'', year:'', trackNo:'' })
  const [status, setStatus] = useState('')
  const [toast, setToast] = useState(null)

  async function load(){
    if (!filePath) return
    setStatus('Loading tags...')
    try{
      const t = await window.api.getTags(filePath)
      setTags(t); setStatus('')
    }catch(e){
      setStatus(''); setToast({ type:'danger', message: e.message })
    }
  }
  async function save(){
    setStatus('Saving...')
    try{
      await window.api.writeTags({ filePath, tags })
      setStatus(''); setToast({ type:'ok', message:'Saved.' })
    }catch(e){
      setStatus(''); setToast({ type:'danger', message: e.message })
    }
  }
  const upd = k => e => setTags({ ...tags, [k]: e.target.value })

  return (
    <div className="p-6 space-y-4">
      <div className="text-xl font-semibold">Tag Editor</div>
      <div className="card space-y-3">
        <div>
          <div className="label">File Path</div>
          <input className="input" placeholder="C:\\Music\\Artist\\Song.mp3" value={filePath} onChange={e=>setFilePath(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Title" value={tags.title} onChange={upd('title')} />
          <Field label="Artist" value={tags.artist} onChange={upd('artist')} />
          <Field label="Album" value={tags.album} onChange={upd('album')} />
          <Field label="Genre" value={tags.genre} onChange={upd('genre')} />
          <Field label="Year" value={tags.year} onChange={upd('year')} />
          <Field label="Track No." value={tags.trackNo} onChange={upd('trackNo')} />
        </div>
        <div className="flex gap-2 items-center">
          <button className="btn" onClick={load}>Load</button>
          <button className="btn" onClick={save}>Save</button>
          <div className="text-sm opacity-70">{status}</div>
        </div>
      </div>
      {toast && <Toast {...toast} onClose={()=>setToast(null)} />}
    </div>
  )
}

function Field({ label, value, onChange }){
  return (
    <div>
      <div className="label">{label}</div>
      <input className="input" value={value} onChange={onChange} />
    </div>
  )
}
