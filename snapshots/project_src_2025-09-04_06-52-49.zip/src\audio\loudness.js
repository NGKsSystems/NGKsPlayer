// src/audio/loudness.js
export async function analyzeLoudnessFromArrayBuffer(arrayBuffer, target = -16) {
  const sr = 44100; const durLimitSec = 60; // 1 min cap
  const ofs = new OfflineAudioContext(2, sr * durLimitSec, sr);
  const audio = await ofs.decodeAudioData(arrayBuffer);
  const hp = ofs.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 60; hp.Q.value = 0.5;
  const hs = ofs.createBiquadFilter(); hs.type = 'highshelf'; hs.frequency.value = 4000; hs.gain.value = 4;

  const src = ofs.createBufferSource(); src.buffer = audio;
  src.connect(hp); hp.connect(hs); hs.connect(ofs.destination);
  src.start();
  const rendered = await ofs.startRendering();

  const rd0 = rendered.getChannelData(0);
  const rd1 = rendered.numberOfChannels > 1 ? rendered.getChannelData(1) : rd0;

  let sum = 0;
  for (let i = 0; i < rendered.length; i++) {
    const s = 0.5 * (rd0[i] + rd1[i]);
    sum += s * s;
  }
  const rms = Math.sqrt(sum / rendered.length);
  const loudnessDb = 20 * Math.log10(rms + 1e-12);
  const gainToTarget = target - loudnessDb;
  return { integratedLoudness: loudnessDb, gainToTarget };
}
