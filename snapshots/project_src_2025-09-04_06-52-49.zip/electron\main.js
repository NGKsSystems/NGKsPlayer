import fs from 'fs'
import { app, BrowserWindow, dialog, ipcMain, protocol } from 'electron'
import path from 'path'
import { fileURLToPath } from 'url'
import Store from 'electron-store'
import Database from 'better-sqlite3'
import { scanFolder } from './scanner.js'
import { initDb } from './schema.js'
import { getTags, writeTags } from './tagger.js'
import { getSmartNext } from './shuffle.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const store = new Store()
let win
const isDev = !!process.env.VITE_DEV_SERVER_URL

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 860,
    backgroundColor: '#0e0f16',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      // keep security on; we serve local files via the custom protocol below
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: true
    }
  })

  const url = process.env.VITE_DEV_SERVER_URL || `file://${path.join(__dirname, '../dist/index.html')}`
  win.loadURL(url)
  if (isDev) win.webContents.openDevTools()
}

app.whenReady().then(() => {
  // --- Custom protocol for local files: local://C:/path/to/file.mp3 ---
  // Allows playing local media from an http(s) renderer (Vite dev server).
  protocol.registerFileProtocol('local', (request, callback) => {
    const raw = request.url.slice('local://'.length)
    const filePath = decodeURIComponent(raw)
    callback({ path: filePath })
  })
  // -------------------------------------------------------------------

  const dbPath = path.join(app.getPath('userData'), 'library.sqlite')
  const db = new Database(dbPath)
  initDb(db)

  // One-time: add pregain column (safe if it already exists)
  try {
    db.prepare(`ALTER TABLE tracks ADD COLUMN pregainDb REAL DEFAULT 0`).run()
  } catch (e) {
    // ignore if column exists
  }

  if (!store.get('settings')) store.set('settings', { autoTrim: true })

  // ===== IPC HANDLERS =====

  ipcMain.handle('settings:get', async () => store.get('settings'))
  ipcMain.handle('settings:set', async (_e, s) => {
    store.set('settings', { ...store.get('settings'), ...s })
    return store.get('settings')
  })

  ipcMain.handle('dialog:openFolder', async () => {
    const result = await dialog.showOpenDialog(win, { properties: ['openDirectory'] })
    if (result.canceled) return null
    return result.filePaths[0]
  })

  ipcMain.handle('library:scan', async (_e, folderPath) => {
    const dbPath2 = path.join(app.getPath('userData'), 'library.sqlite')
    const db2 = new Database(dbPath2)
    initDb(db2)
    return await scanFolder(db2, folderPath)
  })

  ipcMain.handle('library:listArtists', async () => {
    const db3 = new Database(path.join(app.getPath('userData'), 'library.sqlite'))
    return db3.prepare('SELECT artist, COUNT(*) as count FROM tracks GROUP BY artist ORDER BY artist').all()
  })

  ipcMain.handle('library:getAlbumsByArtist', async (_e, artist) => {
    const db4 = new Database(path.join(app.getPath('userData'), 'library.sqlite'))
    return db4.prepare('SELECT album, COUNT(*) as count FROM tracks WHERE artist=? GROUP BY album ORDER BY album').all(artist)
  })

  ipcMain.handle('library:getTracks', async (_e, filter) => {
    const db5 = new Database(path.join(app.getPath('userData'), 'library.sqlite'))
    let q = 'SELECT * FROM tracks'
    const args = []
    if (filter?.artist) { q += ' WHERE artist=?'; args.push(filter.artist) }
    if (filter?.album) { q += (filter?.artist ? ' AND ' : ' WHERE ') + 'album=?'; args.push(filter.album) }
    if (filter?.search) {
      const s = `%${filter.search}%`
      if (args.length) q += ' AND (title LIKE ? OR artist LIKE ? OR album LIKE ?)'
      else q += ' WHERE (title LIKE ? OR artist LIKE ? OR album LIKE ?)'
      args.push(s, s, s)
    }
    q += ' ORDER BY artist, album, trackNo, title'
    return db5.prepare(q).all(...args)
  })

  ipcMain.handle('library:getTrackByPath', async (_e, filePath) => {
    const db6 = new Database(path.join(app.getPath('userData'), 'library.sqlite'))
    return db6.prepare('SELECT * FROM tracks WHERE filePath=?').get(filePath)
  })

  // --- NEW: read file bytes as ArrayBuffer for loudness analysis ---
  ipcMain.handle('fs:readFileBuffer', async (_evt, absPath) => {
    const b = await fs.promises.readFile(absPath)
    return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength)
  })

  // --- NEW: save pregainDb (dB) into tracks table by filePath ---
  ipcMain.handle('db:setPregain', (_evt, { filePath, pregainDb }) => {
    const db7 = new Database(path.join(app.getPath('userData'), 'library.sqlite'))
    db7.prepare('UPDATE tracks SET pregainDb = ? WHERE filePath = ?').run(pregainDb, filePath)
    db7.close()
    return true
  })

  ipcMain.handle('tags:get', async (_e, filePath) => getTags(filePath))
  ipcMain.handle('tags:write', async (_e, payload) => writeTags(payload.filePath, payload.tags))

  ipcMain.handle('shuffle:next', async (_e, currentPath) => getSmartNext(currentPath))

  createWindow()
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow() })
})

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
