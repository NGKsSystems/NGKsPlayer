import React from 'react'

export function Toast({ type='ok', message, onClose }){
  const color = type === 'danger' ? 'bg-danger/20 border-danger/60' :
                type === 'warn' ? 'bg-warn/20 border-warn/60' :
                'bg-ok/20 border-ok/60'
  return (
    <div className={`fixed bottom-4 right-4 max-w-md p-3 rounded-xl border text-sm backdrop-blur ${color}`}>
      <div className="flex items-start gap-3">
        <div className="font-semibold capitalize">{type}</div>
        <div className="opacity-90">{message}</div>
        <button className="ml-auto opacity-70 hover:opacity-100" onClick={onClose}>✕</button>
      </div>
    </div>
  )
}
