import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Toast } from '../components/Toast.jsx'

export default function Library(){
  const [artists, setArtists] = useState([])
  const [scanning, setScanning] = useState(false)
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [toast, setToast] = useState(null)

  async function addFolder(){
    try{
      const folder = await window.api.openFolder()
      if (!folder) return
      setScanning(true); setStatus('Scanning...')
      const res = await window.api.scanLibrary(folder)
      setStatus(`Added/updated ${res.added} tracks`)
      setScanning(false)
      load()
      setToast({ type:'ok', message:`Scan complete: ${res.added} tracks` })
    }catch(e){
      setToast({ type:'danger', message: e.message || 'Scan failed' })
    }finally{
      setScanning(false)
    }
  }

  async function load(){
    const rows = await window.api.listArtists()
    setArtists(rows)
  }

  useEffect(()=>{ load() }, [])

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div className="text-xl font-semibold">Library</div>
        <div className="flex items-center gap-2 ml-auto">
          <input className="input" placeholder="Search title/artist/album…" value={search} onChange={e=>setSearch(e.target.value)} />
          <button className="btn" onClick={addFolder} disabled={scanning}>{scanning ? 'Scanning…' : 'Add Folder'}</button>
          <Link className="btn" to="/now">Now Playing</Link>
          <Link className="btn" to="/tags">Tag Editor</Link>
        </div>
      </div>
      {status && <div className="opacity-80 text-sm">{status}</div>}
      <div className="grid-fill">
        {artists.map(a => (
          <ArtistCard key={a.artist + a.count} artist={a.artist} count={a.count} search={search} />
        ))}
      </div>
      {toast && <Toast {...toast} onClose={()=>setToast(null)} />}
    </div>
  )
}

function ArtistCard({ artist, count, search }){
  const [albums, setAlbums] = React.useState([])
  const [open, setOpen] = React.useState(false)

  async function toggle(){
    if (!open){
      setAlbums(await window.api.getAlbumsByArtist(artist))
    }
    setOpen(!open)
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-semibold">{artist}</div>
          <div className="text-xs opacity-70">{count} tracks</div>
        </div>
        <button className="btn" onClick={toggle}>{open ? 'Hide' : 'View'}</button>
      </div>
      {open && (
        <div className="mt-3 space-y-3">
          {albums.map(al => <Album key={al.album} artist={artist} album={al.album} count={al.count} search={search} />)}
        </div>
      )}
    </div>
  )
}

function Album({ artist, album, count, search }){
  const [tracks, setTracks] = React.useState([])
  const [open, setOpen] = React.useState(false)

  async function toggle(){
    if (!open){
      setTracks(await window.api.getTracks({ artist, album, search }))
    }
    setOpen(!open)
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-medium">{album}</div>
          <div className="text-xs opacity-70">{count} tracks</div>
        </div>
        <button className="btn" onClick={toggle}>{open ? 'Hide' : 'Tracks'}</button>
      </div>
      {open && (
        <div className="mt-2 space-y-2">
          {tracks.map(t => <TrackRow key={t.id} track={t} artist={artist} album={album} />)}
        </div>
      )}
    </div>
  )
}

function TrackRow({ track, artist, album }){
  async function play(){
    // Fetch the full album, then build a queue starting at the clicked track
    const albumTracks = await window.api.getTracks({ artist, album })
    const files = albumTracks.map(t => t.filePath)
    const startIdx = files.findIndex(p => p === track.filePath)
    const ordered =
      startIdx > -1 ? [...files.slice(startIdx), ...files.slice(0, startIdx)] : files

    localStorage.setItem('playQueue', JSON.stringify(ordered))
    localStorage.setItem('playIndex', '0')
    location.hash = '#/now'
  }

  return (
    <div className="flex items-center justify-between bg-white/5 rounded-xl p-2">
      <div className="text-sm">{track.title} <span className="opacity-60">· {track.artist}</span></div>
      <button className="btn" onClick={play}>Play</button>
    </div>
  )
}
