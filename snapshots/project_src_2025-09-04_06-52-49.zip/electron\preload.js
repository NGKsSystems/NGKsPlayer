// electron/preload.js (CommonJS)
const { contextBridge, ipcRenderer } = require('electron');

// Existing API bridge
contextBridge.exposeInMainWorld('api', {
  openFolder: () => ipcRenderer.invoke('dialog:openFolder'),
  scanLibrary: (folder) => ipcRenderer.invoke('library:scan', folder),
  listArtists: () => ipcRenderer.invoke('library:listArtists'),
  getAlbumsByArtist: (artist) => ipcRenderer.invoke('library:getAlbumsByArtist', artist),
  getTracks: (filter) => ipcRenderer.invoke('library:getTracks', filter),
  getTrackByPath: (filePath) => ipcRenderer.invoke('library:getTrackByPath', filePath),
  getTags: (filePath) => ipcRenderer.invoke('tags:get', filePath),
  writeTags: (payload) => ipcRenderer.invoke('tags:write', payload),
  smartNext: (currentPath) => ipcRenderer.invoke('shuffle:next', currentPath),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (s) => ipcRenderer.invoke('settings:set', s),

  // NEW: save pregain (dB) for a track path
  dbSetPregain: (payload) => ipcRenderer.invoke('db:setPregain', payload),
});

// NEW: expose loudness file-read to renderer (returns ArrayBuffer)
contextBridge.exposeInMainWorld('loudness', {
  readFile: (absPath) => ipcRenderer.invoke('fs:readFileBuffer', absPath)
});
