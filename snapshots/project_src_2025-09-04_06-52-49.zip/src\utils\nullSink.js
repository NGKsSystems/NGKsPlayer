export const NULL_SINK = process.platform === 'win32' ? 'NUL' : '/dev/null';
