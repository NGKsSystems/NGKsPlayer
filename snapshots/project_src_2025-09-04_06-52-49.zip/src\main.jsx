import React from "react";
import { createRoot } from "react-dom/client";
import { createHashRouter, RouterProvider } from "react-router-dom";
import "./styles.css";

import Library from "./views/Library.jsx";
import NowPlaying from "./views/NowPlaying.jsx";
import TagEditor from "./views/TagEditor.jsx";

const router = createHashRouter([
  { path: "/", element: <Library /> },
  { path: "/now", element: <NowPlaying /> },
  { path: "/tags", element: <TagEditor /> }
]);

createRoot(document.getElementById("root")).render(<RouterProvider router={router} />);
